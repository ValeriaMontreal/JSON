
var data1 = [
{"Dossier": 1, "Nom": "Tremblay", "Prenom": "Stephan", "Date naissance": "1994-01-02", "Sexe": "M" },
{"Dossier": 2, "Nom": "Smith", "Prenom": "Daniel", "Date naissance": "1988-02-12", "Sexe": "M" },
{"Dossier": 3, "Nom": "Anderson", "Prenom": "Michelle", "Date naissance": "1964-10-06", "Sexe": "F" },
{"Dossier": 4, "Nom": "Duroy", "Prenom": "Serge", "Date naissance": "1974-08-19", "Sexe": "M"},
{"Dossier": 5, "Nom": "Roy", "Prenom": "Vital", "Date naissance": "1984-12-20", "Sexe": "M" },
{"Dossier": 6, "Nom": "Lefevre", "Prenom": "Maria", "Date naissance": "1990-07-07", "Sexe": "F" },
{"Dossier": 7, "Nom": "Duplay", "Prenom": "Valerie", "Date naissance": "1999-08-02", "Sexe": "F" },
{"Dossier": 8, "Nom": "Tremblay", "Prenom": "Stephanie", "Date naissance": "1944-07-06", "Sexe": "F"},
{"Dossier": 9, "Nom": "Breton", "Prenom": "Guy", "Date naissance": "2000-01-09", "Sexe": "M" },
{"Dossier": 10, "Nom": "Chanlat", "Prenom": "Audrey", "Date naissance": "2005-11-08", "Sexe": "F" }
];

for (var i = 0; i < data1.length; i++) {
    let select = document.getElementById("sel");
    let option1 = document.createElement("option");
    option1.text = data1[i].Dossier+'('+data1[i].Nom+data1[i].Prenom+')';
    // option.value = data[i].Prenom;
    select.add(option1);
    select.onchange = function myFunction(){
var result =  select.options[select.selectedIndex].index;
document.getElementById('msg').innerHTML='Selected dossier: <b>'+data1[result-1]['Dossier'] + '</b></br>' +'Nom: <b>'+data1[result-1]['Nom'] + '</b> </br>' + 'Prenom: <b>'+data1[result-1]['Prenom'] +'</b> </br>'+'Date de naissance: <b>' +data1[result-1]['Date naissance']+'</b> </br>'+'Sexe: <b>' +data1[result-1]['Sexe']+'</b> </br>';
document.getElementById('statut').innerHTML='Un patient choissi' ;   
    }

}

