
var data = {
	rows:[
{"Dossier": 1, "Nom": "Tremblay", "Prenom": "Stephan", "Date naissance": "1994-01-02", "Sexe": "M" },
{"Dossier": 2, "Nom": "Smith", "Prenom": "Daniel", "Date naissance": "1988-02-12", "Sexe": "M" },
{"Dossier": 3, "Nom": "Anderson", "Prenom": "Michelle", "Date naissance": "1964-10-06", "Sexe": "F" },
{"Dossier": 4, "Nom": "Duroy", "Prenom": "Serge", "Date naissance": "1974-08-19", "Sexe": "M"},
{"Dossier": 5, "Nom": "Roy", "Prenom": "Vital", "Date naissance": "1984-12-20", "Sexe": "M" },
{"Dossier": 6, "Nom": "Lefevre", "Prenom": "Maria", "Date naissance": "1990-07-07", "Sexe": "F" },
{"Dossier": 7, "Nom": "Duplay", "Prenom": "Valerie", "Date naissance": "1999-08-02", "Sexe": "F" },
{"Dossier": 8, "Nom": "Tremblay", "Prenom": "Stephanie", "Date naissance": "1944-07-06", "Sexe": "F"},
{"Dossier": 9, "Nom": "Breton", "Prenom": "Guy", "Date naissance": "2000-01-09", "Sexe": "M" },
{"Dossier": 10, "Nom": "Chanlat", "Prenom": "Audrey", "Date naissance": "2005-11-08", "Sexe": "F" }
]}


document.addEventListener('DOMContentLoaded', function () {
      var table = document.getElementById('tabPatient')
      data.rows.forEach(function (row) {
        var tr = document.createElement('tr')
        Object.keys(row).forEach(function (key) {
          var td = document.createElement('td')
          td.innerText = row[key]
          tr.appendChild(td)
        })
        table.appendChild(tr)
      })
    })

var dataEtab = {
	rows:[
{"CODE": "0001", "Nom": "Centre médical", "Adresse": "331, rue Ardene, Montreal", "Code Postal": "H2H4U4", "Téléphone": "514-141-9876" },
{"CODE": "0002", "Nom": "Hôpital Nord", "Adresse": "6, rue Bonnevie, Montreal", "Code Postal": "H8V5G6", "Téléphone": "438-999-8335" },
{"CODE": "0003", "Nom": "Hôpital Centre", "Adresse": "3, boul Royal, Montreal", "Code Postal": "H6J5F4", "Téléphone": "450-567-6666" },
{"CODE": "0004", "Nom": "Hôpital Bienvenue", "Adresse": "333, boul Morice, Montreal", "Code Postal": "H9F5V9", "Téléphone": "514-997-0987"},
{"CODE": "0005", "Nom": "Dernier recours", "Adresse": "111, rue Vincent, Montreal", "Code Postal": "H7G4C7", "Téléphone": "450-654-7899" },
{"CODE": "0006", "Nom": "Centre Rive-Sud", "Adresse": "15, rue Valois, Montreal", "Code Postal": "H0V5F1", "Téléphone": "450-454-4321" }

]}


document.addEventListener('DOMContentLoaded', function () {
      var tableEt = document.getElementById('tabEtab')
      dataEtab.rows.forEach(function (row) {
        var tr = document.createElement('tr')
        Object.keys(row).forEach(function (key) {
          var td = document.createElement('td')
          td.innerText = row[key]
          tr.appendChild(td)
        })
        tableEt.appendChild(tr)
      })
    })

var dataHospit = {
	rows:[

{"CODE": "0001", "Dossier": 1, "DateA": "14-08-2018", "DateS": "14-08-2018", "Specialite": "medecine"},
 {"CODE": "0001", "Dossier": 1, "DateA": "14-08-2018", "DateS": "24-08-2018", "Specialite": "chirurgie"},
 {"CODE": "0001", "Dossier": 1, "DateA": "24-08-2018", "DateS": "24-08-2018", "Specialite": "medecine"},
 {"CODE": "0003", "Dossier": 2, "DateA": "03-11-2019", "DateS": "03-11-2019", "Specialite": "medecine"},
 {"CODE": "0003", "Dossier": 2, "DateA": "03-11-2019", "DateS": "04-11-2019", "Specialite": "orthopédie"},
 {"CODE": "0002", "Dossier": 3, "DateA": "12-12-2019", "DateS": "15-12-2019", "Specialite": "medecine"},
 {"CODE": "0002", "Dossier": 3, "DateA": "12-12-2019", "DateS": "15-12-2019", "Specialite": "chirurgie"},
 {"CODE": "0002", "Dossier": 3, "DateA": "15-12-2019", "DateS": "15-12-2019", "Specialite": "medecine"},
 {"CODE": "0004", "Dossier": 4, "DateA": "04-06-1018", "DateS": "04-06-1018", "Specialite": "medecine"},
 {"CODE": "0004", "Dossier": 4, "DateA": "04-06-1018", "DateS": "04-06-1018", "Specialite": "orthopédie"},
 {"CODE": "0003", "Dossier": 5, "DateA": "07-09-2018", "DateS": "07-10-2018", "Specialite": "medecine"},
 {"CODE": "0003", "Dossier": 5, "DateA": "07-09-2018", "DateS": "17-10-2018", "Specialite": "chirurgie"},
 {"CODE": "0002", "Dossier": 6, "DateA": "24-12-2019", "DateS": "24-12-2019", "Specialite": "medecine"},
 {"CODE": "0006", "Dossier": 7, "DateA": "20-02-2018", "DateS": "25-02-2018", "Specialite": "medecine"},
 {"CODE": "0004", "Dossier": 8, "DateA": "01-01-2019", "DateS": "01-01-2019", "Specialite": "medecine"},
 {"CODE": "0002", "Dossier": 9, "DateA": "03-04-2018", "DateS": "03-04-2018", "Specialite": "medecine"},
 {"CODE": "0002", "Dossier": 9, "DateA": "03-04-2018", "DateS": "13-04-2018", "Specialite": "orthopédie"},
 {"CODE": "0001", "Dossier": 10,"DateA": "02-07-2019", "DateS": "02-07-2019", "Specialite": "medecine"},
 {"CODE": "0001", "Dossier": 10,"DateA": "02-07-2019", "DateS": "12-07-2019", "Specialite": "chirurgie"},
 {"CODE": "0001", "Dossier": 10,"DateA": "12-07-2019", "DateS": "12-07-2019", "Specialite": "medecine"},
 {"CODE": "0005", "Dossier": 10,"DateA": "22-07-2019", "DateS": "22-07-2019", "Specialite": "medecine"},
 {"CODE": "0005", "Dossier": 10,"DateA": "22-07-2019", "DateS": "29-07-2019", "Specialite": "chirurgie"},
 {"CODE": "0005", "Dossier": 10,"DateA": "30-07-2019", "DateS": "30-07-2019", "Specialite": "medecine"}
]};



document.addEventListener('DOMContentLoaded', function () {
      var tableHospit = document.getElementById('tabHospit')
      dataHospit.rows.forEach(function (row) {
        var tr = document.createElement('tr')
        Object.keys(row).forEach(function (key) {
          var td = document.createElement('td')
          td.innerText = row[key]
          tr.appendChild(td)
        })
        tableHospit.appendChild(tr)
      })
    })


