


var etab =[ 
{"CODE": "0001", "Nom": "Centre médical", "Adresse": "331, rue Ardene, Montreal", "Code Postal": "H2H4U4", "Telephone": "514-141-9876" },
{"CODE": "0002", "Nom": "Hôpital Nord", "Adresse": "6, rue Bonnevie, Montreal", "Code Postal": "H8V5G6", "Telephone": "438-999-8335" },
{"CODE": "0003", "Nom": "Hôpital Centre", "Adresse": "3, boul Royal, Montreal", "Code Postal": "H6J5F4", "Telephone": "450-567-6666" },
{"CODE": "0004", "Nom": "Hôpital Bienvenue", "Adresse": "333, boul Morice, Montreal", "Code Postal": "H9F5V9", "Telephone": "514-997-0987"},
{"CODE": "0005", "Nom": "Dernier recours", "Adresse": "111, rue Vincent, Montreal", "Code Postal": "H7G4C7", "Telephone": "450-654-7899" },
{"CODE": "0006", "Nom": "Centre Rive-Sud", "Adresse": "15, rue Valois, Montreal", "Code Postal": "H0V5F1", "Telephone": "450-454-4321" }
];

var secialite =[
                {"succursale": "0001", "name": "Centre médical", "noms":["choisir...","medecine","chirurgie"]},
                {"succursale": "0002", "name": "Hôpital Nord", "noms":["choisir...","orthopédie","medecine", "chirurgie"]},
                {"succursale": "0003", "name": "Hôpital Centre", "noms":["choisir...","orthopédie","chirurgie", "medecine"]},
                {"succursale": "0004", "name": "Hôpital Bienvenue", "noms":["choisir...","medecine","orthopédie"]},
                {"succursale": "0005", "name": "Dernier recours", "noms":["choisir...","medecine","chirurgie"]},
                {"succursale": "0006", "name": "Centre Rive-Sud", "noms":["choisir...","medecine"]}              
];  


var dataHospit = [
{"CODE": "0001", "Dossier": 1, "DateA": "14-08-2018", "DateS": "14-08-2018", "Specialite": "medecine"},
 {"CODE": "0001", "Dossier": 1, "DateA": "14-08-2018", "DateS": "24-08-2018", "Specialite": "chirurgie"},
 {"CODE": "0001", "Dossier": 1, "DateA": "24-08-2018", "DateS": "24-08-2018", "Specialite": "medecine"},
 {"CODE": "0003", "Dossier": 2, "DateA": "03-11-2019", "DateS": "03-11-2019", "Specialite": "medecine"},
 {"CODE": "0003", "Dossier": 2, "DateA": "03-11-2019", "DateS": "04-11-2019", "Specialite": "orthopédie"},
 {"CODE": "0002", "Dossier": 3, "DateA": "12-12-2019", "DateS": "15-12-2019", "Specialite": "medecine"},
 {"CODE": "0002", "Dossier": 3, "DateA": "12-12-2019", "DateS": "15-12-2019", "Specialite": "chirurgie"},
 {"CODE": "0002", "Dossier": 3, "DateA": "15-12-2019", "DateS": "15-12-2019", "Specialite": "medecine"},
 {"CODE": "0004", "Dossier": 4, "DateA": "04-06-1018", "DateS": "04-06-1018", "Specialite": "medecine"},
 {"CODE": "0004", "Dossier": 4, "DateA": "04-06-1018", "DateS": "04-06-1018", "Specialite": "orthopédie"},
 {"CODE": "0003", "Dossier": 5, "DateA": "07-09-2018", "DateS": "07-10-2018", "Specialite": "medecine"},
 {"CODE": "0003", "Dossier": 5, "DateA": "07-09-2018", "DateS": "17-10-2018", "Specialite": "chirurgie"},
 {"CODE": "0002", "Dossier": 6, "DateA": "24-12-2019", "DateS": "24-12-2019", "Specialite": "medecine"},
 {"CODE": "0006", "Dossier": 7, "DateA": "20-02-2018", "DateS": "25-02-2018", "Specialite": "medecine"},
 {"CODE": "0004", "Dossier": 8, "DateA": "01-01-2019", "DateS": "01-01-2019", "Specialite": "medecine"},
 {"CODE": "0002", "Dossier": 9, "DateA": "03-04-2018", "DateS": "03-04-2018", "Specialite": "medecine"},
 {"CODE": "0002", "Dossier": 9, "DateA": "03-04-2018", "DateS": "13-04-2018", "Specialite": "orthopédie"},
 {"CODE": "0001", "Dossier": 10,"DateA": "02-07-2019", "DateS": "02-07-2019", "Specialite": "medecine"},
 {"CODE": "0001", "Dossier": 10,"DateA": "02-07-2019", "DateS": "12-07-2019", "Specialite": "chirurgie"},
 {"CODE": "0001", "Dossier": 10,"DateA": "12-07-2019", "DateS": "12-07-2019", "Specialite": "medecine"},
 {"CODE": "0005", "Dossier": 10,"DateA": "22-07-2019", "DateS": "22-07-2019", "Specialite": "medecine"},
 {"CODE": "0005", "Dossier": 10,"DateA": "22-07-2019", "DateS": "29-07-2019", "Specialite": "chirurgie"},
 {"CODE": "0005", "Dossier": 10,"DateA": "30-07-2019", "DateS": "30-07-2019", "Specialite": "medecine"}
];

var obj, indice;
var liste = document.getElementById("selEtab");


for (indice = 0; indice < etab.length; indice++){
obj = etab[indice];
liste.options[liste.length] = new Option(obj["Nom"]);

//etab[indice].Adresse +"</b></br>"+"Téléphone: <b>"+	etab[indice].Telephone+"</b>" ;
}

function remplirNoms() {
var choix = liste.selectedIndex;
var obj;
var tabNoms;
var myAdresse;
var myselNom, myPhone;
myselNom=document.getElementById('selEtab').options[document.getElementById("selEtab").selectedIndex].value;
var listeNoms = document.getElementById("noms");
if (choix !=0) {
obj = secialite[choix-1];
tabNoms = obj["noms"];

}
else
tabNoms = new Array();
listeNoms.length=0;
for (indice in tabNoms) {
listeNoms.options[listeNoms.length] = new Option(tabNoms[indice]);
for (indice in etab){
	if(etab[indice].Nom== myselNom){
 myAdresse=etab[indice].Adresse;
 myPhone=etab[indice].Telephone;}
}
document.getElementById('statut').innerHTML="Adresse: <b>"+	myAdresse +"</b></br>"+"Téléphone: <b>"+ myPhone;	
}

}

function remplirDos() {
var txt = [];
var listedos = document.getElementById("noms");
var objdos = document.getElementById("dossier");

var choix1 = liste.selectedIndex;
var choix2 = document.getElementById("noms").options[document.getElementById("noms").selectedIndex].value;
for (indice in dataHospit) {
if (dataHospit[indice].CODE==choix1 && dataHospit[indice].Specialite==choix2){
txt +=  " CODE:  <b>" +dataHospit[indice].CODE+" </b>" +"Specialite:  <b>" +dataHospit[indice].Specialite +" </b>" +"  DOSSIER:  <b>" +dataHospit[indice].Dossier + " </b>" +" DATE:  <b>" +dataHospit[indice].DateA + " </b>" +"</br>" ;
}
 }
objdos.innerHTML = txt; 

}

