
var data1 = [
{"Dossier": 1, "Nom": "Tremblay", "Prenom": "Stephan", "dateNaissance": "1994-01-02", "Sexe": "M" },
{"Dossier": 2, "Nom": "Smith", "Prenom": "Daniel", "dateNaissance": "1988-02-12", "Sexe": "M" },
{"Dossier": 3, "Nom": "Anderson", "Prenom": "Michelle", "dateNaissance": "1964-10-06", "Sexe": "F" },
{"Dossier": 4, "Nom": "Duroy", "Prenom": "Serge", "dateNaissance": "1974-08-19", "Sexe": "M"},
{"Dossier": 5, "Nom": "Roy", "Prenom": "Vital", "dateNaissance": "1984-12-20", "Sexe": "M" },
{"Dossier": 6, "Nom": "Lefevre", "Prenom": "Maria", "dateNaissance": "1990-07-07", "Sexe": "F" },
{"Dossier": 7, "Nom": "Duplay", "Prenom": "Valerie", "dateNaissance": "1999-08-02", "Sexe": "F" },
{"Dossier": 8, "Nom": "Tremblay", "Prenom": "Stephanie", "dateNaissance": "1944-07-06", "Sexe": "F"},
{"Dossier": 9, "Nom": "Breton", "Prenom": "Guy", "dateNaissance": "2000-01-09", "Sexe": "M" },
{"Dossier": 10, "Nom": "Chanlat", "Prenom": "Audrey", "dateNaissance": "2005-11-08", "Sexe": "F" }
];

var dataHospit = [
{"CODE": "0001", "Dossier": 1, "DateA": "14-08-2018", "DateS": "14-08-2018", "Specialite": "medecine"},
 {"CODE": "0001", "Dossier": 1, "DateA": "14-08-2018", "DateS": "24-08-2018", "Specialite": "chirurgie"},
 {"CODE": "0001", "Dossier": 1, "DateA": "24-08-2018", "DateS": "24-08-2018", "Specialite": "medecine"},
 {"CODE": "0003", "Dossier": 2, "DateA": "03-11-2019", "DateS": "03-11-2019", "Specialite": "medecine"},
 {"CODE": "0003", "Dossier": 2, "DateA": "03-11-2019", "DateS": "04-11-2019", "Specialite": "orthopédie"},
 {"CODE": "0002", "Dossier": 3, "DateA": "12-12-2019", "DateS": "15-12-2019", "Specialite": "medecine"},
 {"CODE": "0002", "Dossier": 3, "DateA": "12-12-2019", "DateS": "15-12-2019", "Specialite": "chirurgie"},
 {"CODE": "0002", "Dossier": 3, "DateA": "15-12-2019", "DateS": "15-12-2019", "Specialite": "medecine"},
 {"CODE": "0004", "Dossier": 4, "DateA": "04-06-1018", "DateS": "04-06-1018", "Specialite": "medecine"},
 {"CODE": "0004", "Dossier": 4, "DateA": "04-06-1018", "DateS": "04-06-1018", "Specialite": "orthopédie"},
 {"CODE": "0003", "Dossier": 5, "DateA": "07-09-2018", "DateS": "07-10-2018", "Specialite": "medecine"},
 {"CODE": "0003", "Dossier": 5, "DateA": "07-09-2018", "DateS": "17-10-2018", "Specialite": "chirurgie"},
 {"CODE": "0002", "Dossier": 6, "DateA": "24-12-2019", "DateS": "24-12-2019", "Specialite": "medecine"},
 {"CODE": "0006", "Dossier": 7, "DateA": "20-02-2018", "DateS": "25-02-2018", "Specialite": "medecine"},
 {"CODE": "0004", "Dossier": 8, "DateA": "01-01-2019", "DateS": "01-01-2019", "Specialite": "medecine"},
 {"CODE": "0002", "Dossier": 9, "DateA": "03-04-2018", "DateS": "03-04-2018", "Specialite": "medecine"},
 {"CODE": "0002", "Dossier": 9, "DateA": "03-04-2018", "DateS": "13-04-2018", "Specialite": "orthopédie"},
 {"CODE": "0001", "Dossier": 10,"DateA": "02-07-2019", "DateS": "02-07-2019", "Specialite": "medecine"},
 {"CODE": "0001", "Dossier": 10,"DateA": "02-07-2019", "DateS": "12-07-2019", "Specialite": "chirurgie"},
 {"CODE": "0001", "Dossier": 10,"DateA": "12-07-2019", "DateS": "12-07-2019", "Specialite": "medecine"},
 {"CODE": "0005", "Dossier": 10,"DateA": "22-07-2019", "DateS": "22-07-2019", "Specialite": "medecine"},
 {"CODE": "0005", "Dossier": 10,"DateA": "22-07-2019", "DateS": "29-07-2019", "Specialite": "chirurgie"},
 {"CODE": "0005", "Dossier": 10,"DateA": "30-07-2019", "DateS": "30-07-2019", "Specialite": "medecine"}
];


var obj, indice;
var liste = document.getElementById("sel");


for (indice = 0; indice < data1.length; indice++){
obj = data1[indice];
liste.options[liste.length] = new Option(obj["Dossier"]);

}


function remplirDos() {
var txt=[];
var indice;
var objdos = document.getElementById("msg");

var choix = liste.selectedIndex;

for (indice in dataHospit) {
if (dataHospit[indice].Dossier==choix){
txt +="DOSSIER:  <b>" +dataHospit[indice].Dossier + "</b>"+"Specialite:  <b>" +dataHospit[indice].Specialite +" </b>" +" DATE:  <b>" +dataHospit[indice].DateA + " </b>" +"</br>" ;
}
 }
objdos.innerHTML = txt; 



 var myselDos, myPrenom, myNom, myDate, mySex, myId;
myId=document.getElementById('sel');
myselDos=myId.options[myId.selectedIndex].value;
 
 
 for (indice in data1){
	if(data1[indice].Dossier== myselDos){
 myPrenom=data1[indice].Prenom;
 myNom=data1[indice].Nom;
 myDate=data1[indice].dateNaissance;
 mySex=data1[indice].Sexe;
}
//} 
document.getElementById('statut').innerHTML="Dossier: <b>"+myselDos+"</b></br>"+"Nom: <b>"+	myNom +"</b></br>"+"Prenom: <b>"+ myPrenom+"</b></br>"+"Date de naissance: <b>"+myDate+"</b></br>"+"Sexe: <b>"+mySex;	
}
} 







